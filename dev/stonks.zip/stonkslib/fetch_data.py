import os
import datetime
from dateutil.relativedelta import relativedelta
from stonkslib.utils import save_ticker_data
from stonkslib.config.category_map import CATEGORY_TIMEFRAME_MAP, TIMEFRAME_LIMITS


def fetch_data(ticker, category, data_dir, verbose=False):
    today = datetime.datetime.today()
    timeframes = CATEGORY_TIMEFRAME_MAP.get(category, ["1d", "1wk"])

    for tf in timeframes:
        if tf not in TIMEFRAME_LIMITS:
            if verbose:
                print(f"⚠️  Unsupported timeframe: {tf}")
            continue

        start_delta = TIMEFRAME_LIMITS[tf]
        start = today - start_delta

        if verbose:
            print(f"[↓] Fetching {ticker} ({tf}) from {start.date()} to {today.date()}")

        try:
            save_ticker_data(ticker, start=start, end=today, interval=tf, data_dir=data_dir)
        except Exception as e:
            if verbose:
                print(f"[!] Failed to fetch {ticker} ({tf}): {e}")
