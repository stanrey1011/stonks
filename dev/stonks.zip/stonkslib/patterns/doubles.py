"""
Detect double top and double bottom chart patterns.

This module defines `find_double_patterns`, which can analyze historical price data
to find double top or bottom formations based on extrema and price similarity.

You may use `find_double_top_bottom` as an alias for CLI compatibility.
"""

import logging
import os
import pandas as pd
import numpy as np
from scipy.signal import argrelextrema

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# Path to your historical ticker CSVs
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "ticker_data")


def find_double_patterns(ticker, window=5, type="top", df=None):
    """
    Detect double top or bottom patterns in a given ticker's historical data.

    Parameters:
        ticker (str): Stock or asset symbol
        window (int): Window for local extrema detection
        type (str): 'top' or 'bottom'
        df (DataFrame): Optional preloaded data

    Returns:
        List of tuples: (start_date, end_date, pattern_type, confidence_score)
    """
    if df is None:
        file_path = os.path.join(DATA_DIR, f"{ticker}.csv")
        logging.info(f"[DEBUG] Looking for: {file_path}")
        if not os.path.exists(file_path):
            logging.error(f"[ERROR] File does not exist: {file_path}")
            raise FileNotFoundError(f"CSV for ticker '{ticker}' not found.")
        df = pd.read_csv(file_path, parse_dates=["Date"])
        logging.debug(f"[DEBUG] {ticker} columns: {df.columns}")

    # Ensure required structure
    if "Date" not in df.columns or "Close" not in df.columns:
        raise ValueError(f"Required columns missing in data for {ticker}: {df.columns.tolist()}")

    df = df.sort_values("Date").copy()
    df["Close"] = pd.to_numeric(df["Close"], errors="coerce")
    df = df.dropna(subset=["Close"])

    is_top = type == "top"
    extrema_func = np.greater_equal if is_top else np.less_equal
    extrema_idx = argrelextrema(df["Close"].values, extrema_func, order=window)[0]

    pattern_label = "Double Top" if is_top else "Double Bottom"
    patterns = []

    for i in range(len(extrema_idx) - 1):
        i1, i2 = extrema_idx[i], extrema_idx[i + 1]
        p1, p2 = df.iloc[i1]["Close"], df.iloc[i2]["Close"]

        # If prices are within 5% of each other
        if abs(p1 - p2) / max(p1, p2) < 0.05:
            days_apart = (df.iloc[i2]["Date"] - df.iloc[i1]["Date"]).days
            if 10 <= days_apart <= 60:
                confidence = round(0.8 - (abs(p1 - p2) / max(p1, p2)), 2)
                patterns.append((
                    df.iloc[i1]["Date"],
                    df.iloc[i2]["Date"],
                    pattern_label,
                    confidence
                ))

    return patterns


# Alias for CLI compatibility
find_double_top_bottom = find_double_patterns


if __name__ == "__main__":
    ticker = "AAPL"
    top_patterns = find_double_patterns(ticker, type="top")
    bottom_patterns = find_double_patterns(ticker, type="bottom")
    patterns = top_patterns + bottom_patterns

    if patterns:
        logging.info(f"[{ticker}] Double Top/Bottom Patterns:")
        for s, e, label, c in patterns:
            logging.info(f" - {label} from {s.date()} to {e.date()} (confidence: {c})")
    else:
        logging.info(f"[{ticker}] No double top/bottom patterns found.")
