from pathlib import Path

# Define the full rewritten version of fetch_ranges.py using the new category mapping and updated logic
fetch_ranges_code = """
import os
import yaml
import logging
from datetime import datetime, timedelta
from stonkslib.utils.fetch_data import fetch_ticker_data
from stonkslib.config.category_map import CATEGORY_TIMEFRAMES

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "stonkslib", "data", "ticker_data")
TICKERS_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)), "tickers.yaml")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

def load_tickers():
    with open(TICKERS_FILE, "r") as f:
        return yaml.safe_load(f)

def fetch_all_ranges():
    tickers_by_category = load_tickers()
    end_date = datetime.today()
    
    for category, tickers in tickers_by_category.items():
        timeframes = CATEGORY_TIMEFRAMES.get(category, [])
        for ticker in tickers:
            for tf, years in timeframes:
                start_date = end_date - timedelta(days=365 * years)
                try:
                    logging.info(f"[↓] Fetching {ticker} ({tf}) from {start_date.date()} to {end_date.date()}")
                    fetch_ticker_data(ticker, tf, start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"), DATA_DIR)
                except Exception as e:
                    logging.error(f"[!] Failed to fetch {ticker} ({tf}): {e}")

if __name__ == "__main__":
    fetch_all_ranges()
"""

# Save it into the expected location
fetch_ranges_path = Path.cwd() / "stonkslib" / "utils" / "fetch_ranges.py"
fetch_ranges_path.parent.mkdir(parents=True, exist_ok=True)
fetch_ranges_path.write_text(fetch_ranges_code.strip())

fetch_ranges_path.name
