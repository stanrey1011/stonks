"""
Utility functions for loading ticker data from multiple timeframes.
"""

import os
import logging
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

DEBUG = False

# Base data directory: ~/stonks/data/ticker_data/
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "ticker_data")

def load_ticker_data(ticker, interval="1d"):
    """
    Load and return OHLCV data for a specific ticker and interval.
    Defaults to daily ('1d') if no interval provided.
    """
    file_path = os.path.join(DATA_DIR, interval, f"{ticker}.csv")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"[ERROR] No data file found at {file_path}")

    df = pd.read_csv(file_path, parse_dates=["Date"])
    df = df.sort_values("Date")

    if DEBUG:
        logging.info(f"[DEBUG] Loaded {ticker} [{interval}] rows: {len(df)}")

    return df
